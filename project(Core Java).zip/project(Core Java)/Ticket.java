package project;
import java.util.List;
import java.util.LinkedList;

public class Ticket {
	 private int pnr;
	 private BusBooking bookedBus;
	 private List<BookTicket> passengerList;
	
	public Ticket(int pnr, BusBooking bookedBus, List<BookTicket> passengerList) {
		this.pnr = pnr;
		this.bookedBus = bookedBus;
		this.passengerList = passengerList;
	}
	public int getPnr() {
		return pnr;
	}
	public void setPnr(int pnr) {
		this.pnr = pnr;
	}
	public BusBooking getBookedBus() {
		return bookedBus;
	}
	public void setBookedBus(BusBooking bookedBus) {
		this.bookedBus = bookedBus;
	}
	public List<BookTicket> getPassengerList() {
		return passengerList;
	}
	public void setPassengerList(List<BookTicket> passengerList) {
		this.passengerList = passengerList;
	}
	}

