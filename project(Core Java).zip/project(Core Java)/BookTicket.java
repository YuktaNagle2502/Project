package project;

public class BookTicket {
	private static  String passengerName;
	private static  int passengerAge;

public BookTicket(String passengerName,int passengerAge) {
	this.passengerName=passengerName;
	this.passengerAge=passengerAge;
}

public static String getPassengerName()
{
	return passengerName;
}
public void setPassengerName(String passengerName)
{
	this.passengerName=passengerName;
}
public static int getPassengerAge()
{
	return passengerAge;
}
public void setPassengerAge(int passengerAge)
{
	this.passengerAge=passengerAge;
}

}